package Driver;

public interface reusableCode {
	
	public static String applicationUrl="https://demo.guru99.com/test/login.html";
	public static String driverPath="C:\\Users\\NIVETHA\\eclipse-workspace\\Learn_Framework\\selenium_Driver\\chromedriver.exe";

}
