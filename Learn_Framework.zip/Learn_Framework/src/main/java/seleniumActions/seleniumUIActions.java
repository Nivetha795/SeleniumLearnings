package seleniumActions;

import java.io.IOException;

import org.openqa.selenium.By;

import Driver.LaunchDriver;
import readInputTestData.readerFile;

public class seleniumUIActions {
	
	public static void entername() throws IOException
	{
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Gurru.Demosite.Emailaddress.input"))).sendKeys("nivetha95@gmail.com");
		
	}
	
	public static void enterpassword() throws IOException
	{
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Gurru.Demosite.EmailPassword.input"))).sendKeys("runcode");
		
	}
	
	public static void clickLogin() throws IOException
	{
		//LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Gurru.Demosite.SubmitLogin.button"))).click();
		
	}
	
	public static void entercontactInfo() throws IOException
	{
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Contact.Information.FirstName.input"))).sendKeys("Nivetha");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Contact.Information.LastName.input"))).sendKeys("G");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Contact.Information.Phone.input"))).sendKeys("93747847474");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Contact.Information.UserName.input"))).sendKeys("NivethaG@gmail.com");
		
	}
	
	public static void enterMailingInfo() throws IOException
	{
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Mailing.Information.Address.input"))).sendKeys("first cross street");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Mailing.Information.City.input"))).sendKeys("chennai");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Mailing.Information.state.input"))).sendKeys("TN");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Mailing.Information.postalCode.input"))).sendKeys("600100");
		
	}
	
	public static void enterUserInfo() throws IOException
	{
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("User.Information.Email.input"))).sendKeys("NivethaG");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("User.Information.Password.input"))).sendKeys("Learncode@2024");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("User.Information.ConfirmPassword.input"))).sendKeys("Learncode@2024");
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("User.Information.submit.input"))).click();
		
	}

}
