package seleniumActions;

import java.io.IOException;

import org.openqa.selenium.By;

import Driver.LaunchDriver;
import readInputTestData.readerFile;

public class seleniumUIActions {
	
	public static void entername() throws IOException
	{
		LaunchDriver.driver.findElement(By.xpath(readerFile.readORproperties("Gurru.Demosite.Emailaddress.input"))).sendKeys("nivetha95@gmail.com");
		
	}

}
