package RedBus.com;



import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Driver.LaunchDriver;
import Driver.reusableCode;
import seleniumActions.seleniumUIActions;

public class bookingFlight {

		//public static void main(String[] args) throws IOException {
	@BeforeMethod
	public static void launchUrl()
	{
		LaunchDriver.readDriver(reusableCode.driverPath, reusableCode.applicationUrl);
	}
	@Test
	public static void searchFlightData() throws IOException
	{
			
			LaunchDriver.maximizeBrowser();
			seleniumUIActions.entername();
			seleniumUIActions.enterpassword();
			seleniumUIActions.clickLogin();
			//LaunchDriver.closeBrowser();
			
		}
	@Test
	public static void bookFlight() throws IOException
	{
			
			LaunchDriver.maximizeBrowser();
			seleniumUIActions.entername();
			seleniumUIActions.enterpassword();
			seleniumUIActions.clickLogin();
			//LaunchDriver.closeBrowser();
			
		}

	
		
	}
