package RedBus.com;



import java.io.IOException;

import Driver.LaunchDriver;
import Driver.reusableCode;
import seleniumActions.seleniumUIActions;

public class launchBrowser {

		public static void main(String[] args) throws IOException {
			LaunchDriver.readDriver(reusableCode.driverPath, reusableCode.applicationUrl);
			LaunchDriver.maximizeBrowser();
			seleniumUIActions.entername();
			//LaunchDriver.closeBrowser();
			
		}
	
		
	}
