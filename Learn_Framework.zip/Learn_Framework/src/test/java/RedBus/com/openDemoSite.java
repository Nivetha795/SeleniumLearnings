package RedBus.com;

import java.io.IOException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Driver.LaunchDriver;
import Driver.reusableCode;
import seleniumActions.seleniumUIActions;

public class openDemoSite {
	
	@BeforeMethod
	public static void launchUrl()
	{
		LaunchDriver.readDriver(reusableCode.driverPath, reusableCode.applicationUrl);
	}
	
	@Test
	public static void contactInformation() throws IOException
	{
		LaunchDriver.maximizeBrowser();	
		seleniumUIActions.entercontactInfo();
			
	}
	
	@Test
	public static void mailingInformation() throws IOException
	{
		LaunchDriver.maximizeBrowser();
		seleniumUIActions.enterMailingInfo();
	}
	
	@Test
	public static void userInformation() throws IOException
	{
		LaunchDriver.maximizeBrowser();
		seleniumUIActions.enterUserInfo();
	}

}
